<?php
require_once("../model/cadastroAnimal.php");

/*Class cadastrar animnal*/

class cadastroController{

    private $cadastro;
    public function __construct(){
        $this->cadastro = new Cadastro();
        $this->incluir();
    }

    /*Função de atrinuição dos dados ao baco*/

    private function incluir(){
        $this->cadastro->setNome($_POST['nome']);
        $this->cadastro->setIdade($_POST['idade']);
        $this->cadastro->setPet($_POST['pet']);
        $this->cadastro->setRaca($_POST['raca']);
        $this->cadastro->setDono($_POST['dono']);
        $this->cadastro->setContato($_POST['contato']);
        $result = $this->cadastro->incluir();
        if($result >= 1){
            echo "<script>alert('Registro concluído com sucesso!');document.location='../view/cadastro.php'</script>";
        }else{
            echo "<script>alert('Erro ao gravar registro!, verifique se o animal não está duplicado');history.back()</script>";
        }
    }
}
new cadastroController();
