<?php
require_once("../model/banco.php");

/*Class listar dados da tabela*/

class listarController{

    private $lista;

    public function __construct(){
        $this->lista = new Banco();
        $this->criarTabela();

    }
/*Função exibir dados na tabela*/

    private function criarTabela(){
        $row = $this->lista->getAnimal();
        foreach ($row as $value){
            echo "<tr>";
             echo "<th>".$value['id'] ."</th>";
            echo "<th>".$value['nome'] ."</th>";
            echo "<td>".$value['idade'] ."</td>";
            echo "<td>".$value['pet'] ."</td>";
            echo "<td>".$value['raca'] ."</td>";
            echo "<td>".$value['dono'] ."</td>";
             echo "<td>".$value['contato'] ."</td>";
            echo "<td><a class='btn btn-primary' href='editar.php?id=".$value['nome']."'>Editar</a><a class='btn btn-danger' href='../controller/ControllerDeletar.php?id=".$value['nome']."'>Excluir</a></td>";
            echo "</tr>";
        }
    }
}

