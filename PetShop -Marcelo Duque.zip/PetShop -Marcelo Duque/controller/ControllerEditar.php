<?php
require_once("../model/banco.php");

/*Class editar animal*/

class editarController {

    private $editar;
    private $nome;
    private $idade;
    private $pet;
    private $raca;
    private $dono;
    private $contato;

    public function __construct($id){
        $this->editar = new Banco();
        $this->criarFormulario($id);
    }

    /* recupera dados atuais e exibe*/

    private function criarFormulario($id){
        $row = $this->editar->pesquisaAnimal($id);
        $this->nome         =$row['nome'];
        $this->idade        =$row['idade'];
        $this->pet          =$row['pet'];
        $this->raca         =$row['raca'];
        $this->dono         =$row['dono'];
        $this->contato      =$row['contato'];

    }

    /*Função editar furmulário do animal*/

    public function editarFormulario($nome,$idade,$pet,$raca,$dono,$contato,$id){
        if($this->editar->updateAnimal($nome,$idade,$pet,$raca,$dono,$contato,$id) == TRUE){
            echo "<script>alert('Registro incluído com sucesso!');document.location='../view/index.php'</script>";
        }else{
            echo "<script>alert('Erro ao gravar registro!');history.back()</script>";
        }
    }
    public function getNome(){
        return $this->nome;
    }
    public function getIdade(){
        return $this->idade;
    }
    public function getPet(){
        return $this->pet;
    }
    public function getRaca(){
        return $this->raca;
    }
    public function getDono(){
        return $this->dono;
    }
    public function getContato(){
        return $this->contato;
    }


}
$id = filter_input(INPUT_GET, 'id');
$editar = new editarController($id);
if(isset($_POST['submit'])){
    $editar->editarFormulario($_POST['nome'],$_POST['idade'],$_POST['pet'],$_POST['raca'],$_POST['dono'],$_POST['contato'],$_POST['id']);
}
?>
