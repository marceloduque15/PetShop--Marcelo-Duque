<!DOCTYPE HTML>
<html>
<?php include("head.php") ?>

<body>
    <?php include("menu.php") ?>
    <center>
    <div class="row">
        <form method="post" action="../controller/ControllerCadastro.php" id="form" name="form" onsubmit="validar(document.form); return false;" class="col-10">
            <div class="form-group">
                <h2> Cadastro </h2>
                <strong>Nome</strong>
                <input class="form-control" type="text" id="nome" name="nome" style="width: 500px" required autofocus>
                <strong>Idade</strong>
                <input class="form-control" type="text" id="idade" name="idade"  style="width: 500px" required>
                <strong>Animal</strong>
                <select class="form-control" aria-label="Default select example" name="pet" id="pet" style="width: 500px">
                <option value="Cachorro">Cachorro</option>
                <option value="Gato" >Gato</option>>
                </select>
                <strong>Raça</strong>
                <input class="form-control" type="text" id="raca" name="raca" style="width: 500px"  required>
                <strong>Dono</strong>
                <input class="form-control" type="text" id="dono" name="dono" style="width: 500px" required>
                <strong>Contato</strong>
                <input type="text" id="contato" name="contato"  style="width: 500px" class="form-control" placeholder="Ex.: (00) 0000-0000" required>
                </div>
                <div class="form-group">
                <button type="submit" class="btn btn-success" id="cadastrar">Cadastrar</button>
            </div>
        </form>
    </div>
</center>
</body>
</html>
