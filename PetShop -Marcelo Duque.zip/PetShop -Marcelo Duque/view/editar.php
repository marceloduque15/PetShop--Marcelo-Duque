<!DOCTYPE HTML>
<html>
<?php include("head.php") ?>

<body>
  <!-- Incluindo o menu -->
   <?php include("menu.php") ?>

   <!-- Criação dos campos editar -->
   <center>
    <?php require_once("../controller/ControllerEditar.php");?>
    <div class="row">
        <form method="post" action="../controller/ControllerEditar.php" id="form" name="form" onsubmit="validar(document.form); return false;" class="col-10">
            <h2> Editar Cadastro </h2>
            <div class="form-group">
                <strong>Nome</strong>
                <input class="form-control" type="text" id="nome" name="nome" style="width: 500px" value="<?php echo $editar->getNome(); ?>" required autofocus>
                <strong>Idade</strong>
                <input class="form-control" type="text" id="idade" name="idade" style="width: 500px" value="<?php echo $editar->getIdade(); ?>" required>
                <strong>Animal</strong>
                <select class="form-control" aria-label="Default select example" name="pet" id="pet" style="width: 500px" value="<?php echo $editar->getPet(); ?>" required>
                <option value="Cachorro">Cachorro</option>
                <option value="Gato" >Gato</option>>
                </select> 
                <strong>Raça</strong>
                <input class="form-control" type="text" id="raca" name="raca" style="width: 500px" value="<?php echo $editar->getRaca(); ?>" required>
                <strong>Dono</strong>
                <input class="form-control" type="text" id="dono" name="dono" style="width: 500px" value="<?php echo $editar->getDono(); ?>" required>
                <strong>Contato</strong>
                <input class="form-control" type="text" id="contato" name="contato" style="width: 500px" value="<?php echo $editar->getContato(); ?>" required>
                </div>
                <div class="form-group">
                <input type="hidden" name="id" value="<?php echo $editar->getNome();?>">
                <button type="submit" class="btn btn-success" id="editar" name="submit" value="editar">Editar</button>
            </div>
        </form>
    </div>
</center>
</body>
</html>
