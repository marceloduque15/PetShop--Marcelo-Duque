
/* CRIAÇÃO DO BANCO DE DADOS NECESSÁRIA*/

CREATE DATABASE petshop DEFAULT CHARACTER SET utf8;
USE petshop;

CREATE TABLE animais (
	id            int(1) NOT NULL AUTO_INCREMENT,
    nome          VARCHAR(255) NOT NULL,
    idade         int(50) NOT NULL,
    pet    		  VARCHAR(255) NOT NULL,
   	raca          VARCHAR(255) NOT NULL,
    dono          VARCHAR(255) NOT NULL,
    contato       VARCHAR(50) NOT NULL,
PRIMARY KEY (id))
