# PROJETO DESAFIO SOFRMAKERS

### Objetivo: 

>Desenvolver um sistema em PHP e MySQL de um Pet Shop.

### Detalhes:

>Os Registros devem contar com as seguintes informações:


1. Id
2. Nome
3. Idade
4. Animal
5. Raça
6. Nome do dono
7. Contato

### Regras:

1. Cada animal de estimação precisa ter um identificador único, nome, idade, se é gato ou cachorro e sua respectiva raça; Além do nome e telefone para contato de seu dono.

### Detalhes sobre o programa:

1.  init.php são os arquivos de configurações do sistema.
2.  diretório "view" é onde fica todas as telas do sistema.
3.  diretório "controller" é onde fica fica as funcionalidades do sistema que interagem com o banco de dados.
4.  diretório "model" é onde fica os arquivos de conexão com o banco de dados.

No diretório "view" existem 3 páginas principais: editar.php, cadastro.php e index.php. a página head e menu são os escopos do HTML e Menu do sistemas respectivamente.

O arquivo script.sql é o scrip em sql que cria o banco e a tabela.

Para visualizar a lista no index, efetue o primeiro cadastro.
