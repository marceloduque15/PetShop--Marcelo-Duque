<?php
require_once("banco.php");

class Cadastro extends Banco {

    private $nome;
    private $idade;
    private $pet;
    private $raca;
    private $dono;
    private $contato;

    //Metodos Set
    public function setNome($string){
        $this->nome = $string;
    }
    public function setIdade($string){
        $this->idade = $string;
    }
    public function setPet($string){
        $this->pet = $string;
    }
    public function setRaca($string){
        $this->raca = $string;
    }
    public function setDono($string){
        $this->dono = $string;
    }
    public function setContato($string){
        $this->contato = $string;
    }
    //Metodos Get
    public function getNome(){
        return $this->nome;
    }
    public function getIdade(){
        return $this->idade;
    }
    public function getPet(){
        return $this->pet;
    }
    public function getRaca(){
        return $this->raca;
    }
    public function getDono(){
        return $this->dono;
    }
    public function getContato(){
        return $this->contato;
    }


    public function incluir(){
        return $this->setAnimal($this->getNome(),$this->getIdade(),$this->getPet(),$this->getRaca(),$this->getDono(),$this->getContato());
    }
}
?>
