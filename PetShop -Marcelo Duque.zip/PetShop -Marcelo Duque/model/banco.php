<?php

require_once("../init.php");
class Banco{

    protected $mysqli;

    public function __construct(){
        $this->conexao();
    }

    private function conexao(){
        $this->mysqli = new mysqli(BD_SERVIDOR, BD_USUARIO , BD_SENHA, BD_BANCO);
    }

    /*Função inserir dados na tabela*/

    public function setAnimal($nome,$idade,$pet,$raca,$dono,$contato){
        $stmt = $this->mysqli->prepare("INSERT INTO animais (`nome`, `idade`, `pet`, `raca`, `dono`, `contato`) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("ssssss",$nome,$idade,$pet,$raca,$dono,$contato);
         if( $stmt->execute() == TRUE){
            return true ;
        }else{
            return false;
        }

    }

    /*Função recuperar dados na tabela*/

    public function getAnimal(){
        $result = $this->mysqli->query("SELECT * FROM animais");
        while($row = $result->fetch_array(MYSQLI_ASSOC)){
            $array[] = $row;
        }
        return $array;

    }

    /*Função deletar dados no tabela*/

    public function deleteAnimal($id){
        if($this->mysqli->query("DELETE FROM `animais` WHERE `nome` = '".$id."';")== TRUE){
            return true;
        }else{
            return false;
        }

    }

    /*Função redirecionar animal selecionado para edição*/

    public function pesquisaAnimal($id){
        $result = $this->mysqli->query("SELECT * FROM animais WHERE nome='$id'");
        return $result->fetch_array(MYSQLI_ASSOC);

    }

    /*Função atualizar tabela pós edição*/
    public function updateAnimal($nome,$idade,$pet,$raca,$dono,$contato,$id){
        $stmt = $this->mysqli->prepare("UPDATE `animais` SET `nome` = ?, `idade`=?, `pet`=?, `raca`=?, `dono`=?,`contato` = ? WHERE `nome` = ?");
        $stmt->bind_param("sssssss",$nome,$idade,$pet,$raca,$dono,$contato,$id);
        if($stmt->execute()==TRUE){
            return true;
        }else{
            return false;
        }
    }
}
?>
